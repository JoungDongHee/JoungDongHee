package service;

import static db.JdbcUtil.close;
import static db.JdbcUtil.commit;
import static db.JdbcUtil.getConnection;
import static db.JdbcUtil.rollback;

import java.sql.Connection;

import bean.BoardBean;
import DAO.BoardDAO;

public class BoardWriteService {

	public boolean registArticle(BoardBean board) {
		Connection con = getConnection();
		BoardDAO boardDAO = BoardDAO.getInstense();
		boardDAO.setConnection(con);
		BoardBean boardbean = new BoardBean();
		boolean WriteResult = false;
		
		int result = boardDAO.Write(boardbean);
		
		if(result>0) {
			WriteResult = true;
			commit(con);
		} else {
			WriteResult = false;
			rollback(con);
		}
		
		close(con);
		return WriteResult;
	}

}
